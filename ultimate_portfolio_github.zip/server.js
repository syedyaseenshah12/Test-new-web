import express from 'express';
import fetch from 'node-fetch';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

// Serve static frontend (built single-file)
app.use(express.static(path.join(__dirname, 'public')));

// API endpoint to proxy to OpenAI
app.post('/api/chat', async (req, res) => {
  const message = req.body?.message || '';
  if(!message) return res.status(400).json({ error: 'No message' });

  try {
    const apiKey = process.env.OPENAI_API_KEY;
    if(!apiKey) return res.status(500).json({ error: 'Server not configured with OPENAI_API_KEY' });

    const payload = {
      model: 'gpt-3.5-turbo',
      messages: [
        { role: 'system', content: 'You are a helpful assistant answering for Syed Yaseen Shah portfolio.'},
        { role: 'user', content: message }
      ],
      max_tokens: 400,
      temperature: 0.2
    };

    const r = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(payload)
    });

    if(!r.ok){
      const txt = await r.text();
      return res.status(502).json({ error: 'OpenAI error', details: txt });
    }

    const json = await r.json();
    const reply = json.choices?.[0]?.message?.content || 'No reply from AI';
    res.json({ reply });
  } catch (err) {
    console.error('Chat error', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// fallback to index.html for SPA routes
app.get('*', (req,res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`Server running on port ${PORT}`));
