# Ultimate Portfolio - Syed Yaseen Shah

This repository contains a static frontend and a small Express backend that proxies requests to OpenAI.
It is ready to host. The backend serves the frontend from `/public` and exposes `/api/chat`.

## What's included
- `public/index.html` - frontend (three.js galaxy + AI chat UI)
- `server.js` - Express server + /api/chat proxy
- `package.json` - Node dependencies
- `.env.example` - sample env file
- `Dockerfile` - optional container

## Quick local run
1. Copy `.env.example` to `.env` and add your OpenAI API key:
```
OPENAI_API_KEY=your_openai_key_here
```
2. Install and run:
```
npm install
npm start
```
3. Open http://localhost:3000

## Deploy
You can deploy to Render, Railway, Heroku, or any Node-capable host.
- For Render: Create a Web Service, connect the repo, set `OPENAI_API_KEY` in environment, set build command `npm install` and start command `npm start`.
- For Docker: build with `docker build -t ultimate-portfolio .` and run with `docker run -p 3000:3000 -e OPENAI_API_KEY=... ultimate-portfolio`.

## Notes
- Keep your OPENAI_API_KEY secret — do not commit it.
- The chat endpoint uses `gpt-3.5-turbo` by default; you can change model and parameters in `server.js`.
